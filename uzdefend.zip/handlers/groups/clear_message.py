from aiogram import Router, F
from aiogram.types import Message

clear_message_router = Router()
@clear_message_router.message(F.left_chat_member)
async def left_chat_clear_answer(message: Message):
    await message.delete()

@clear_message_router.message(F.new_chat_members)
async def new_chat_clear_answer(message: Message):
    await message.delete()

@clear_message_router.message(F.new_chat_title)
async def new_chat_title_clear_answer(message: Message):
    await message.delete()

@clear_message_router.message(F.new_chat_photo)
async def new_chat_photo_clear_answer(message: Message):
    await message.delete()

@clear_message_router.message(F.delete_chat_photo)
async def delete_chat_photo_clear_answer(message: Message):
    await message.delete()

@clear_message_router.message(F.pinned_message)
async def pinned_message_clear_answer(message: Message):
    await message.delete()

@clear_message_router.message(F.video_chat_started)
async def video_chat_started_clear_answer(message: Message):
    await message.delete()

@clear_message_router.message(F.video_chat_ended)
async def video_chat_ended_clear_answer(message: Message):
    await message.delete()