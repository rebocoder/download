from aiogram import Router, F, Bot
from aiogram.filters import Command, and_f
from aiogram.types import Message

delete_message_router = Router()

@delete_message_router.message(and_f(Command(commands='del', prefix='/!.'), F.chat.type == 'supergroup' or F.chat.type == 'group'))
async def delete_answer(message: Message, bot: Bot):
    user = await bot.get_chat_member(message.chat.id, message.from_user.id)
    if user.status == "administrator" or user.status == "creator":
        if message.reply_to_message:
            await message.delete()
            await message.reply_to_message.delete()
        else:
            await message.delete()
            await message.answer(f"No message found.")
    else:
        await message.delete()