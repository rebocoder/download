from aiogram import Bot, Router, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
import keyboards as kb, states as st, data

message_router = Router()

@message_router.message(CommandStart())
async def start_message(message: Message):
    if message.chat.type == 'private':
        await message.reply(f"Beta testing has started, please report any bugs using the /help command.")
    else:
        await message.delete()

@message_router.message(Command(commands='help', prefix='/'))
async def help_message(message: Message):
    if message.chat.type == 'private':
        await message.reply(f"<b>Help section</b>\n\nHello dear user, our bot is open for beta testing, "
                            f'try our bot too, if you encounter any errors, let us know via the '
                            f'<b>"Send question"</b> button below.', reply_markup=kb.help_kb)
    else:
        await message.delete()

@message_router.callback_query(F.data == 'send_question')
async def send_question_message(call: CallbackQuery, state: FSMContext):
    await call.message.delete()
    await call.message.answer("We're sorry you encountered an error, please send us the details of the error "
                              "so we can look into it and fic it.", reply_markup=kb.quest)
    await state.set_state(st.send_questions.send_question)

@message_router.message(st.send_questions.send_question, Command(commands='help') and CommandStart() and F.text != 'Cancel')
async def accepted_message(message: Message, state: FSMContext):
    for admin in data.ADMINS:
        await message.forward(admin)
    await message.reply("Your request the has been successfully submitted to the moderators.", reply_markup=kb.remove)
    await state.clear()

@message_router.message(F.text == 'Cancel')
async def cancelled_message(message: Message, state: FSMContext):
    await message.answer("The application procces has been cancelled.", reply_markup=kb.remove)
    await state.clear()