from aiogram.fsm.state import State, StatesGroup

class send_questions(StatesGroup):
    send_question = State()