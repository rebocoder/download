import asyncio, logging
from loader import dp, bot
from handlers import message_router, clear_message_router, delete_message_router

async def main() -> None:
    dp.include_routers(message_router, clear_message_router, delete_message_router)
    try:
        await dp.start_polling(bot)
        await bot.delete_webhook(drop_pending_updates=True)
    finally:
        await bot.session.close()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main(), debug=True)