from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove

quest = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text='Cancel')]],
                            resize_keyboard=True)

remove = ReplyKeyboardRemove(remove_keyboard=True)