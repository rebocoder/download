from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

help_kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='Send question',
                                                                      callback_data='send_question')]])